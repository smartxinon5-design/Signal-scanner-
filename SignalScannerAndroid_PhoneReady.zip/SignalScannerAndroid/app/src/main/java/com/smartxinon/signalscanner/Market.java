package com.smartxinon.signalscanner;

import java.io.*; import java.net.*; import java.util.*; import org.json.*;

public class Market {
  public static List<Double> closes(String symbol) throws Exception {
    URL u=new URL("https://api.binance.com/api/v3/klines?symbol="+URLEncoder.encode(symbol,"UTF-8")+"&interval=1m&limit=100");
    HttpURLConnection c=(HttpURLConnection)u.openConnection(); c.setConnectTimeout(8000); c.setReadTimeout(8000); c.setRequestMethod("GET");
    BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream())); StringBuilder b=new StringBuilder(); String s; while((s=r.readLine())!=null)b.append(s); r.close(); c.disconnect();
    JSONArray a=new JSONArray(b.toString()); List<Double> out=new ArrayList<>(); for(int i=0;i<a.length();i++) out.add(Double.parseDouble(a.getJSONArray(i).getString(4))); return out;
  }
  static double ema(List<Double> x,int n){double k=2.0/(n+1),e=x.get(0); for(int i=1;i<x.size();i++) e=x.get(i)*k+e*(1-k); return e;}
  static double rsi(List<Double> x,int n){ if(x.size()<n+1)return 50; double g=0,l=0; int st=x.size()-n; for(int i=st;i<x.size();i++){double d=x.get(i)-x.get(i-1); if(d>0)g+=d;else l-=d;} if(l==0)return 100; return 100-(100/(1+g/l)); }
  public static Signal analyze(List<Double> x){
    if(x.size()<30) return null; double e9=ema(x,9), e21=ema(x,21), rr=rsi(x,14), p=x.get(x.size()-1);
    double prev9=ema(x.subList(0,x.size()-1),9), prev21=ema(x.subList(0,x.size()-1),21);
    String dir="WAIT"; int score=0;
    if(prev9<=prev21 && e9>e21 && rr>=50 && rr<70){dir="CALL";score=3;}
    else if(prev9>=prev21 && e9<e21 && rr>30 && rr<=50){dir="PUT";score=3;}
    else if(e9>e21 && rr>=55 && rr<70){dir="CALL";score=2;}
    else if(e9<e21 && rr>30 && rr<=45){dir="PUT";score=2;}
    return new Signal(dir,score,p,e9,e21,rr);
  }
  public static class Signal { public final String direction; public final int score; public final double price,e9,e21,rsi; Signal(String d,int s,double p,double a,double b,double r){direction=d;score=s;price=p;e9=a;e21=b;rsi=r;} }
}
