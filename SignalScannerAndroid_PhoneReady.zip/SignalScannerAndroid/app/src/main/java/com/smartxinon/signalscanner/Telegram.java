package com.smartxinon.signalscanner;
import java.io.*; import java.net.*; import java.net.URLEncoder;
public class Telegram { public static boolean send(String token,String chat,String msg){ try{ String q="https://api.telegram.org/bot"+token+"/sendMessage?chat_id="+URLEncoder.encode(chat,"UTF-8")+"&text="+URLEncoder.encode(msg,"UTF-8"); HttpURLConnection c=(HttpURLConnection)new URL(q).openConnection(); c.setRequestMethod("GET"); c.setConnectTimeout(8000); c.setReadTimeout(8000); int code=c.getResponseCode(); c.disconnect(); return code==200; }catch(Exception e){return false;} } }
