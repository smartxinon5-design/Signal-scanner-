package com.smartxinon.signalscanner;
import android.app.*; import android.content.*; import android.os.*; import java.util.*;

public class SignalService extends Service {
  private Handler h=new Handler(Looper.getMainLooper()); private Runnable job; private String last="";
  @Override public int onStartCommand(Intent i,int flags,int id){ startForeground(7, notification("Scanner running")); scan(); return START_STICKY; }
  private void scan(){ job=()->{ new Thread(()->{ try{ android.content.SharedPreferences p=getSharedPreferences("cfg",0); String sym=p.getString("symbol","BTCUSDT").toUpperCase(); String token=p.getString("token",""); String chat=p.getString("chat",""); Market.Signal s=Market.analyze(Market.closes(sym)); if(s!=null && !s.direction.equals("WAIT")){ String key=s.direction+Math.round(s.price*1000000); if(!key.equals(last)){last=key; String msg="📡 1-MIN SIGNAL\nAsset: "+sym+"\nSignal: "+s.direction+"\nConfidence setup: "+s.score+"/3\nPrice: "+s.price+"\nRSI: "+String.format(java.util.Locale.US,"%.1f",s.rsi)+"\nEMA9: "+s.e9+"\nEMA21: "+s.e21+"\n\nSignal only — not a guarantee."; if(!token.isEmpty()&&!chat.isEmpty())Telegram.send(token,chat,msg); } }catch(Exception ignored){} }).start(); h.postDelayed(this::scan,60000); }; h.post(job); }
  private Notification notification(String t){ String ch="scanner"; NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE); if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel(ch,"Signal Scanner",NotificationManager.IMPORTANCE_LOW)); return new Notification.Builder(this,ch).setContentTitle("1-Min Signal Scanner").setContentText(t).setSmallIcon(android.R.drawable.ic_menu_compass).build(); }
  @Override public void onDestroy(){if(job!=null)h.removeCallbacks(job);super.onDestroy();}
  @Override public android.os.IBinder onBind(Intent i){return null;}
}
