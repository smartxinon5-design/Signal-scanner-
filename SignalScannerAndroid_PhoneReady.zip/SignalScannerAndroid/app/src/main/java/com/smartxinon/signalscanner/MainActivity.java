package com.smartxinon.signalscanner;
import android.app.*; import android.os.*; import android.content.*; import android.content.pm.PackageManager; import android.graphics.Color; import android.view.*; import android.widget.*;

public class MainActivity extends Activity {
 EditText symbol,token,chat; TextView status; android.content.SharedPreferences cfg;
 @Override public void onCreate(Bundle b){super.onCreate(b); cfg=getSharedPreferences("cfg",0); build(); if(Build.VERSION.SDK_INT>=33)requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},5);}
 TextView tv(String s){TextView t=new TextView(this);t.setText(s);t.setTextSize(16);t.setPadding(8,14,8,8);return t;}
 void build(){ LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(24,24,24,24); ScrollView sc=new ScrollView(this);sc.addView(root);
 root.addView(tv("1-MIN SIGNAL SCANNER")); root.addView(tv("Market: Binance public 1-minute candles • signal-only"));
 symbol=new EditText(this);symbol.setHint("Symbol, e.g. BTCUSDT");symbol.setText(cfg.getString("symbol","BTCUSDT"));root.addView(symbol);
 token=new EditText(this);token.setHint("Telegram bot token");token.setText(cfg.getString("token",""));root.addView(token);
 chat=new EditText(this);chat.setHint("Telegram chat ID");chat.setText(cfg.getString("chat",""));root.addView(chat);
 Button save=new Button(this);save.setText("SAVE SETTINGS");save.setOnClickListener(v->{cfg.edit().putString("symbol",symbol.getText().toString().trim()).putString("token",token.getText().toString().trim()).putString("chat",chat.getText().toString().trim()).apply();status.setText("Saved.");});root.addView(save);
 Button start=new Button(this);start.setText("START 1-MIN SCANNER");start.setOnClickListener(v->{cfg.edit().putString("symbol",symbol.getText().toString().trim()).putString("token",token.getText().toString().trim()).putString("chat",chat.getText().toString().trim()).apply();Intent i=new Intent(this,SignalService.class);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);status.setText("Scanner running in background. Signals go to Telegram when configured.");});root.addView(start);
 Button stop=new Button(this);stop.setText("STOP SCANNER");stop.setOnClickListener(v->{stopService(new Intent(this,SignalService.class));status.setText("Scanner stopped.");});root.addView(stop);
 status=tv("Ready. Configure Telegram, then start.");root.addView(status);root.addView(tv("Strategy: EMA 9/21 + RSI 14. A signal is generated only when conditions align. This does not place trades automatically and does not guarantee profit."));setContentView(sc); }
}
