# 1-Min Signal Scanner Android App

A signal-only Android app for 1-minute market scanning and Telegram alerts.

## Features
- Binance public 1-minute candles (default BTCUSDT)
- EMA 9 / EMA 21 + RSI 14 signal logic
- CALL / PUT style directional signals
- Telegram Bot API alerts
- Foreground background scanner
- No automatic order execution

## Phone-only build
See **PHONE_BUILD_GUIDE.md**. The recommended current phone-only build environment is **Code on the Go (CoGo)**, which supports Android 9+, Java/Kotlin Android projects, and local APK builds on Android phones.

## GitHub Actions alternative
The included workflow can also build `app-debug.apk` in GitHub Actions.

## Safety
This is a signal tool, not a profit guarantee. Test with demo/paper trading first. Do not expose your Telegram bot token.
