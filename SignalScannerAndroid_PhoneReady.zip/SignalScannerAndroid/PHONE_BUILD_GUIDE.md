# Build Signal Scanner APK directly on your Android phone

This project is designed to be built on-device with **Code on the Go (CoGo)**. No Termux, laptop, or Android Studio is required.

## 1. Install Code on the Go

Use the official App Dev for All download page:
https://appdevforall.org/codeonthego/

Choose the ARM64 version for most phones from 2018 onward. CoGo currently supports Android 9+, ARM32 and ARM64, and Android Gradle Plugin 7.3.0 through 8.11.0.

## 2. Download this project

Download `SignalScannerAndroid.zip` to your phone and extract it with your file manager.

The folder you open in CoGo must be the folder containing:
- `settings.gradle`
- `build.gradle`
- `app/`

## 3. Open the project in CoGo

Open Code on the Go → Open existing project → choose the extracted `SignalScannerAndroid` folder.

Allow CoGo to install/download any build components it requests. The first build can take longer.

## 4. Build the APK

Open the project and use CoGo's **Build** action. Choose the debug APK if prompted.

The output should be:
`app/build/outputs/apk/debug/app-debug.apk`

Use CoGo's install/run action to install it on the phone.

## 5. Configure Telegram

Create a Telegram bot using BotFather, send the bot a message, obtain the chat ID, then enter both values in the app.

Do not post your bot token publicly.

## 6. Start the scanner

Enter an asset such as `BTCUSDT`, save the settings, then tap **START 1-MIN SCANNER**.

The app uses Binance public 1-minute candles and sends signal-only alerts to Telegram. It does not place trades automatically.

## Troubleshooting

- If CoGo asks for a toolchain update, let it complete before building.
- If the build fails, open CoGo's Build Output and use the first error shown; later errors may only be consequences of that first error.
- Keep at least several GB of free storage. CoGo's current requirements list about 3.5 GB minimum storage and Android 9+.
