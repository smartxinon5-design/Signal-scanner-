# Signal Scanner Android

Signal-only Android app using Yahoo Finance 1-minute chart data and EMA 9/21 + RSI 14.

The app does not place trades and does not guarantee profitable signals.

## Build

Use Gradle 8.9+ and Java 17 with Android Gradle Plugin 8.7.3.
