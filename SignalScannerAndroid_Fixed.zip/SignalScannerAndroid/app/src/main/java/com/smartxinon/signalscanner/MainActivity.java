package com.smartxinon.signalscanner;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private EditText symbolInput;
    private EditText tokenInput;
    private EditText chatInput;
    private TextView statusView;
    private TextView signalView;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean running = false;
    private SharedPreferences prefs;
    private String lastSignalKey = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("signal_scanner", MODE_PRIVATE);
        buildUi();
    }

    private TextView label(String text, float size) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(Color.DKGRAY);
        view.setPadding(0, 8, 0, 8);
        return view;
    }

    private EditText field(String hint, String value) {
        EditText view = new EditText(this);
        view.setHint(hint);
        view.setText(value);
        view.setSingleLine(true);
        view.setBackgroundResource(R.drawable.edit_bg);
        return view;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 28, 28, 28);
        root.setBackgroundColor(Color.WHITE);

        TextView title = label("SIGNAL SCANNER", 26);
        title.setTextColor(Color.rgb(21, 101, 192));
        root.addView(title);
        root.addView(label("1-minute scanner • EMA 9/21 + RSI 14", 14));

        root.addView(label("Yahoo Finance symbol (example: EURUSD=X)", 13));
        symbolInput = field("Symbol", prefs.getString("symbol", "EURUSD=X"));
        root.addView(symbolInput, new LinearLayout.LayoutParams(-1, 58));

        root.addView(label("Telegram Bot Token", 13));
        tokenInput = field("123456:ABC...", prefs.getString("token", ""));
        root.addView(tokenInput, new LinearLayout.LayoutParams(-1, 58));

        root.addView(label("Telegram Chat ID", 13));
        chatInput = field("Chat ID", prefs.getString("chat", ""));
        root.addView(chatInput, new LinearLayout.LayoutParams(-1, 58));

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        Button startButton = new Button(this);
        startButton.setText("START");
        Button stopButton = new Button(this);
        stopButton.setText("STOP");
        buttons.addView(startButton, new LinearLayout.LayoutParams(0, 58, 1));
        buttons.addView(stopButton, new LinearLayout.LayoutParams(0, 58, 1));
        root.addView(buttons);

        Button testButton = new Button(this);
        testButton.setText("TEST TELEGRAM");
        root.addView(testButton, new LinearLayout.LayoutParams(-1, 58));

        signalView = label("No signal yet", 20);
        signalView.setTextColor(Color.DKGRAY);
        root.addView(signalView);

        statusView = label("Stopped", 14);
        root.addView(statusView);
        root.addView(label("Signal-only app. It does not place trades. Signals are not guaranteed.", 12));

        setContentView(root);

        startButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                saveSettings();
                startScanner();
            }
        });
        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { stopScanner(); }
        });
        testButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                saveSettings();
                new Thread(new Runnable() {
                    @Override public void run() { sendTelegram("Signal Scanner test message"); }
                }).start();
            }
        });
    }

    private void saveSettings() {
        prefs.edit()
                .putString("symbol", symbolInput.getText().toString().trim())
                .putString("token", tokenInput.getText().toString().trim())
                .putString("chat", chatInput.getText().toString().trim())
                .apply();
    }

    private void startScanner() {
        if (running) return;
        running = true;
        statusView.setText("Scanning every 60 seconds...");
        scanOnce();
    }

    private void stopScanner() {
        running = false;
        handler.removeCallbacksAndMessages(null);
        statusView.setText("Stopped");
    }

    private void scanOnce() {
        if (!running) return;
        final String symbol = symbolInput.getText().toString().trim();

        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    ArrayList<Double> closes = fetchPrices(symbol);
                    final String result = computeSignal(closes);
                    final String time = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());

                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            signalView.setText(result);
                            statusView.setText("Last scan: " + time);
                        }
                    });

                    if (!result.startsWith("WAIT")) {
                        String key = symbol + "|" + result;
                        if (!key.equals(lastSignalKey)) {
                            lastSignalKey = key;
                            sendTelegram(formatTelegram(symbol, result));
                        }
                    }
                } catch (final Exception error) {
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            statusView.setText("Error: " + safeMessage(error));
                        }
                    });
                }

                handler.postDelayed(new Runnable() {
                    @Override public void run() { scanOnce(); }
                }, 60000L);
            }
        }).start();
    }

    private ArrayList<Double> fetchPrices(String symbol) throws Exception {
        String encoded = URLEncoder.encode(symbol, StandardCharsets.UTF_8.name());
        String urlText = "https://query1.finance.yahoo.com/v8/finance/chart/" + encoded
                + "?interval=1m&range=1d";

        HttpURLConnection connection = (HttpURLConnection) new URL(urlText).openConnection();
        connection.setRequestMethod("GET");
        connection.setConnectTimeout(15000);
        connection.setReadTimeout(15000);
        connection.setRequestProperty("User-Agent", "Mozilla/5.0");

        int code = connection.getResponseCode();
        InputStream stream = code >= 400 ? connection.getErrorStream() : connection.getInputStream();
        String body = readAll(stream);
        connection.disconnect();

        if (code < 200 || code >= 300) {
            throw new Exception("Market data HTTP " + code);
        }

        JSONObject root = new JSONObject(body);
        JSONArray results = root.getJSONObject("chart").optJSONArray("result");
        if (results == null || results.length() == 0 || results.isNull(0)) {
            throw new Exception("No market data for " + symbol);
        }

        JSONObject first = results.getJSONObject(0);
        JSONObject indicators = first.getJSONObject("indicators");
        JSONArray quotes = indicators.getJSONArray("quote");
        JSONArray closes = quotes.getJSONObject(0).getJSONArray("close");

        ArrayList<Double> values = new ArrayList<>();
        for (int i = 0; i < closes.length(); i++) {
            if (!closes.isNull(i)) values.add(closes.getDouble(i));
        }
        if (values.size() < 30) throw new Exception("Not enough 1-minute data");
        return values;
    }

    private String readAll(InputStream stream) throws Exception {
        if (stream == null) return "";
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
        StringBuilder builder = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) builder.append(line);
        reader.close();
        return builder.toString();
    }

    private double ema(ArrayList<Double> values, int period) {
        double multiplier = 2.0 / (period + 1.0);
        double value = values.get(0);
        for (int i = 1; i < values.size(); i++) {
            value = values.get(i) * multiplier + value * (1.0 - multiplier);
        }
        return value;
    }

    private double rsi(ArrayList<Double> values, int period) {
        int start = Math.max(1, values.size() - period);
        double gain = 0.0;
        double loss = 0.0;
        for (int i = start; i < values.size(); i++) {
            double delta = values.get(i) - values.get(i - 1);
            if (delta > 0) gain += delta;
            else loss -= delta;
        }
        if (loss == 0.0) return 100.0;
        double averageGain = gain / period;
        double averageLoss = loss / period;
        double rs = averageGain / averageLoss;
        return 100.0 - (100.0 / (1.0 + rs));
    }

    private String computeSignal(ArrayList<Double> values) {
        double ema9 = ema(values, 9);
        double ema21 = ema(values, 21);
        double rsi14 = rsi(values, 14);
        double price = values.get(values.size() - 1);

        if (ema9 > ema21 && rsi14 >= 52.0 && rsi14 <= 72.0 && price > ema9) {
            return String.format(Locale.US, "CALL • EMA9>EMA21 • RSI %.1f", rsi14);
        }
        if (ema9 < ema21 && rsi14 >= 28.0 && rsi14 <= 48.0 && price < ema9) {
            return String.format(Locale.US, "PUT • EMA9<EMA21 • RSI %.1f", rsi14);
        }
        return "WAIT • EMA/RSI not aligned";
    }

    private String formatTelegram(String symbol, String signal) {
        return "SIGNAL SCANNER\n\n"
                + "Asset: " + symbol + "\n"
                + "Timeframe: 1 minute\n"
                + "Signal: " + signal + "\n\n"
                + "Signal only - no automatic trade execution.";
    }

    private void sendTelegram(String message) {
        final String token = prefs.getString("token", "").trim();
        final String chat = prefs.getString("chat", "").trim();

        if (token.isEmpty() || chat.isEmpty()) {
            runOnUiThread(new Runnable() {
                @Override public void run() { statusView.setText("Add Telegram token and chat ID"); }
            });
            return;
        }

        HttpURLConnection connection = null;
        try {
            String query = "chat_id=" + URLEncoder.encode(chat, StandardCharsets.UTF_8.name())
                    + "&text=" + URLEncoder.encode(message, StandardCharsets.UTF_8.name());
            URL url = new URL("https://api.telegram.org/bot" + token + "/sendMessage?" + query);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(15000);
            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) throw new Exception("Telegram HTTP " + code);
        } catch (final Exception error) {
            runOnUiThread(new Runnable() {
                @Override public void run() { statusView.setText("Telegram error: " + safeMessage(error)); }
            });
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private String safeMessage(Exception error) {
        String message = error.getMessage();
        return message == null ? error.getClass().getSimpleName() : message;
    }

    @Override
    protected void onDestroy() {
        stopScanner();
        super.onDestroy();
    }
}
