package com.smartxinon.signalscanner;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
    EditText symbol, token, chatId;
    TextView status, signal;
    Button start, stop, test;
    Handler handler = new Handler(Looper.getMainLooper());
    boolean running=false;
    SharedPreferences prefs;
    String lastSignal="";

    @Override public void onCreate(Bundle b){ super.onCreate(b); prefs=getSharedPreferences("cfg",0); buildUi(); }
    TextView tv(String s,int sp){ TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(Color.DKGRAY); t.setPadding(0,8,0,8); return t; }
    EditText ed(String hint,String value){ EditText e=new EditText(this); e.setHint(hint); e.setText(value); e.setSingleLine(); e.setBackgroundResource(com.smartxinon.signalscanner.R.drawable.edit_bg); return e; }
    public void buildUi(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28,28,28,28); root.setBackgroundColor(Color.WHITE);
        TextView title=tv("SIGNAL SCANNER",26); title.setTextColor(Color.rgb(21,101,192)); root.addView(title);
        root.addView(tv("1-minute market scanner • EMA 9/21 + RSI 14",14));
        root.addView(tv("Yahoo Finance symbol (example: EURUSD=X)",13)); symbol=ed("Symbol","EURUSD=X"); root.addView(symbol,new LinearLayout.LayoutParams(-1,55));
        root.addView(tv("Telegram Bot Token",13)); token=ed("123456:ABC...",prefs.getString("token","")); root.addView(token,new LinearLayout.LayoutParams(-1,55));
        root.addView(tv("Telegram Chat ID",13)); chatId=ed("Chat ID",prefs.getString("chat","")); root.addView(chatId,new LinearLayout.LayoutParams(-1,55));
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        start=new Button(this); start.setText("START"); stop=new Button(this); stop.setText("STOP"); test=new Button(this); test.setText("TEST TELEGRAM");
        row.addView(start,new LinearLayout.LayoutParams(0,55,1)); row.addView(stop,new LinearLayout.LayoutParams(0,55,1)); root.addView(row); root.addView(test,new LinearLayout.LayoutParams(-1,55));
        signal=tv("No signal yet",22); signal.setTextColor(Color.DKGRAY); root.addView(signal);
        status=tv("Stopped",14); root.addView(status);
        root.addView(tv("The app sends signals only; it does not place trades. Signals are not guaranteed.",12));
        setContentView(root);
        start.setOnClickListener(v->{save(); startBot();}); stop.setOnClickListener(v->stopBot()); test.setOnClickListener(v->{save(); new Thread(()->sendTelegram("🔔 Signal Scanner test message")).start();});
    }
    void save(){prefs.edit().putString("token",token.getText().toString().trim()).putString("chat",chatId.getText().toString().trim()).apply();}
    void startBot(){ if(running)return; running=true; status.setText("Scanning every 60 seconds…"); scan(); }
    void stopBot(){running=false; handler.removeCallbacksAndMessages(null); status.setText("Stopped");}
    void scan(){ if(!running)return; final String sym=symbol.getText().toString().trim(); new Thread(()->{ try{ ArrayList<Double> c=fetch(sym); String s=computeSignal(c); runOnUiThread(()->{ signal.setText(s); status.setText("Last scan: "+new SimpleDateFormat("HH:mm:ss").format(new Date())); }); if(!s.equals("WAIT")&&!s.equals(lastSignal)){lastSignal=s; sendTelegram(formatTelegram(sym,s));} }catch(Exception e){runOnUiThread(()->status.setText("Error: "+e.getMessage()));} handler.postDelayed(this::scan,60000); }).start(); }
    ArrayList<Double> fetch(String sym)throws Exception{ String url="https://query1.finance.yahoo.com/v8/finance/chart/"+URLEncoder.encode(sym,"UTF-8")+"?interval=1m&range=1d"; HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection(); c.setConnectTimeout(15000); c.setReadTimeout(15000); c.setRequestProperty("User-Agent","Mozilla/5.0"); BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream())); StringBuilder b=new StringBuilder(); String x; while((x=r.readLine())!=null)b.append(x); JSONObject o=new JSONObject(b.toString()); JSONArray a=o.getJSONObject("chart").getJSONArray("result").getJSONObject(0).getJSONObject("indicators").getJSONArray("quote").getJSONObject(0).getJSONArray("close"); ArrayList<Double> out=new ArrayList<>(); for(int i=0;i<a.length();i++) if(!a.isNull(i)) out.add(a.getDouble(i)); if(out.size()<30)throw new Exception("Not enough 1-minute data"); return out; }
    double ema(ArrayList<Double> x,int n){double k=2.0/(n+1), e=x.get(0); for(int i=1;i<x.size();i++)e=x.get(i)*k+e*(1-k); return e;}
    double rsi(ArrayList<Double> x,int n){double gain=0,loss=0; for(int i=Math.max(1,x.size()-n);i<x.size();i++){double d=x.get(i)-x.get(i-1); if(d>0)gain+=d; else loss-=d;} if(loss==0)return 100; double rs=(gain/n)/(loss/n); return 100-(100/(1+rs));}
    String computeSignal(ArrayList<Double> x){double e9=ema(x,9),e21=ema(x,21),r=rsi(x,14); double p=x.get(x.size()-1); if(e9>e21 && r>=52 && r<=72 && p>e9)return "CALL  •  EMA9>EMA21  •  RSI "+String.format(Locale.US,"%.1f",r); if(e9<e21 && r<=48 && r>=28 && p<e9)return "PUT  •  EMA9<EMA21  •  RSI "+String.format(Locale.US,"%.1f",r); return "WAIT  •  EMA9/21 or RSI not aligned";}
    String formatTelegram(String sym,String s){return "📊 SIGNAL SCANNER\n\nAsset: "+sym+"\nTimeframe: 1 minute\nSignal: "+s+"\n\nSignal only — no automatic trade execution.";}
    void sendTelegram(String msg){String t=prefs.getString("token",""); String chat=prefs.getString("chat",""); if(t.isEmpty()||chat.isEmpty()){runOnUiThread(()->status.setText("Add Telegram token and chat ID"));return;} try{String q="https://api.telegram.org/bot"+t+"/sendMessage?chat_id="+URLEncoder.encode(chat,"UTF-8")+"&text="+URLEncoder.encode(msg,"UTF-8"); HttpURLConnection c=(HttpURLConnection)new URL(q).openConnection(); c.setRequestMethod("GET"); c.setConnectTimeout(15000); c.getResponseCode();}catch(Exception e){runOnUiThread(()->status.setText("Telegram error: "+e.getMessage()));}}
    @Override protected void onDestroy(){super.onDestroy(); stopBot();}
}
